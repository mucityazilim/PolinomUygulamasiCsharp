﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace polinomUy
{
    public partial class Form1 : Form
    {
        // Bilgisayar Mühendisi Sadık ŞAHİN

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, c, x, sonuc;
            double delta, x1, x2;

            if (txtx.Text == "" || txta.Text == "" || txtb.Text == "" || txtc.Text == "")
            {
                MessageBox.Show("Lütfen tüm alanları giriniz ");
            }
            else
            {
                x = int.Parse(txtx.Text);
                a = int.Parse(txta.Text);
                b = int.Parse(txtb.Text);
                c = int.Parse(txtc.Text);

                sonuc = a * x * x + b * x + c;

                lblSonuc.Text = sonuc.ToString();


                delta = b * b - 4 * a * c;
                if (delta < 0)
                {
                    lblKokDurumu.Text = "Real kök yok ";
                }
                else if (delta == 0)
                {
                    lblKokDurumu.Text = "Çakışık kök var ";
                    x1 = -b / (2 * a);
                    lblKok.Text = "x1 = " + x1.ToString();
                }
                else
                {
                    lblKokDurumu.Text = "Farklı iki kök var ";
                    x1 = (-b - (Math.Sqrt(delta ) ) )   / (2*a) ;
                    x2 = (-b + (Math.Sqrt(delta))) / (2 * a); 
                    lblKok.Text = "\nx1 = " + x1.ToString() + "\nx2 = " + x2.ToString() ;


                }


            }
        }
    }
}
